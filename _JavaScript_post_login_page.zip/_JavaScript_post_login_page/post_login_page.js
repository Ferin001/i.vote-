/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		post_login_page
 *	@date 		Friday 02nd of September 2022 03:55:02 PM
 *	@title 		Page 1
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "1728px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);
var page_post_login_page_ek1 = document.createElement("div");
page_post_login_page_ek1.id = "page_post_login_page_ek1";
page_post_login_page_ek1.style.width = "1728px";
page_post_login_page_ek1.style.height = "1117px";
page_post_login_page_ek1.style.left = "0px";
page_post_login_page_ek1.style.top = "0px";
page_post_login_page_ek1.style.position = "absolute";
content_container.appendChild(page_post_login_page_ek1);

var _bg__post_login_page_ek2 = document.createElement("div");
_bg__post_login_page_ek2.id = "_bg__post_login_page_ek2";
_bg__post_login_page_ek2.style.left = "0px";
_bg__post_login_page_ek2.style.top = "0px";
_bg__post_login_page_ek2.style.width = "1728px";
_bg__post_login_page_ek2.style.height = "1117px";
_bg__post_login_page_ek2.style.background = 'rgba(85,85,85,1)';

page_post_login_page_ek1.appendChild(_bg__post_login_page_ek2);

var side_section = document.createElement("div");
side_section.id = "side_section";
side_section.style.left = "0px";
side_section.style.top = "4px";
side_section.style.width = "281px";
side_section.style.height = "1117px";
side_section.style.background = 'rgba(248.63,213.05,144,1)';

page_post_login_page_ek1.appendChild(side_section);

var top_section = document.createElement("div");
top_section.id = "top_section";
top_section.style.left = "0px";
top_section.style.top = "0px";
top_section.style.width = "1728px";
top_section.style.height = "213px";
top_section.style.background = 'rgba(143.44,142,139.85,1)';

page_post_login_page_ek1.appendChild(top_section);

var joined_rooms = document.createElement("div");
joined_rooms.id = "joined_rooms";
joined_rooms.style.width = "80px";
joined_rooms.style.height = "784px";
joined_rooms.style.left = "95px";
joined_rooms.style.top = "274px";
joined_rooms.style.position = "absolute";
page_post_login_page_ek1.appendChild(joined_rooms);

var ellipse_1 = document.createElement("div");
ellipse_1.id = "ellipse_1";
ellipse_1.style.left = "0px";
ellipse_1.style.top = "0px";
ellipse_1.style.width = "80px";
ellipse_1.style.height = "80px";
ellipse_1.style.borderRadius = "40px / 40px";
ellipse_1.style.background = 'rgba(255,255,255,1)';

joined_rooms.appendChild(ellipse_1);

var ellipse_1_ek1 = document.createElement("div");
ellipse_1_ek1.id = "ellipse_1_ek1";
ellipse_1_ek1.style.left = "0px";
ellipse_1_ek1.style.top = "176px";
ellipse_1_ek1.style.width = "80px";
ellipse_1_ek1.style.height = "80px";
ellipse_1_ek1.style.borderRadius = "40px / 40px";
ellipse_1_ek1.style.background = 'rgba(255,255,255,1)';

joined_rooms.appendChild(ellipse_1_ek1);

var ellipse_2 = document.createElement("div");
ellipse_2.id = "ellipse_2";
ellipse_2.style.left = "0px";
ellipse_2.style.top = "352px";
ellipse_2.style.width = "80px";
ellipse_2.style.height = "80px";
ellipse_2.style.borderRadius = "40px / 40px";
ellipse_2.style.background = 'rgba(255,255,255,1)';

joined_rooms.appendChild(ellipse_2);

var ellipse_3 = document.createElement("div");
ellipse_3.id = "ellipse_3";
ellipse_3.style.left = "0px";
ellipse_3.style.top = "528px";
ellipse_3.style.width = "80px";
ellipse_3.style.height = "80px";
ellipse_3.style.borderRadius = "40px / 40px";
ellipse_3.style.background = 'rgba(255,255,255,1)';

joined_rooms.appendChild(ellipse_3);

var ellipse_4 = document.createElement("div");
ellipse_4.id = "ellipse_4";
ellipse_4.style.left = "0px";
ellipse_4.style.top = "704px";
ellipse_4.style.width = "80px";
ellipse_4.style.height = "80px";
ellipse_4.style.borderRadius = "40px / 40px";
ellipse_4.style.background = 'rgba(255,255,255,1)';

joined_rooms.appendChild(ellipse_4);

var search_bar = document.createElement("div");
search_bar.id = "search_bar";
search_bar.style.width = "935px";
search_bar.style.height = "60px";
search_bar.style.left = "396px";
search_bar.style.top = "76px";
search_bar.style.position = "absolute";
page_post_login_page_ek1.appendChild(search_bar);

var rectangle_3 = document.createElement("div");
rectangle_3.id = "rectangle_3";
rectangle_3.style.left = "29px";
rectangle_3.style.top = "0px";
rectangle_3.style.width = "877px";
rectangle_3.style.height = "60px";
rectangle_3.style.background = 'rgba(255,255,255,1)';

search_bar.appendChild(rectangle_3);

var ellipse_5 = document.createElement("div");
ellipse_5.id = "ellipse_5";
ellipse_5.style.left = "0px";
ellipse_5.style.top = "0px";
ellipse_5.style.width = "59px";
ellipse_5.style.height = "60px";
ellipse_5.style.borderRadius = "29.5px / 30px";
ellipse_5.style.background = 'rgba(255,255,255,1)';

search_bar.appendChild(ellipse_5);

var ellipse_6 = document.createElement("div");
ellipse_6.id = "ellipse_6";
ellipse_6.style.left = "876px";
ellipse_6.style.top = "0px";
ellipse_6.style.width = "59px";
ellipse_6.style.height = "60px";
ellipse_6.style.borderRadius = "29.5px / 30px";
ellipse_6.style.background = 'rgba(255,255,255,1)';

search_bar.appendChild(ellipse_6);

var find_room____ = document.createElement("div");
find_room____.innerHTML = "Find Room ...";
find_room____.style.textAlign = "left";
find_room____.id = "find_room____";
find_room____.style.left = "434px";
find_room____.style.top = "86px";
find_room____.style.width = "231px";
find_room____.style.height = "62px";
find_room____.style.fontFamily = "Istok Web";
find_room____.style.fontSize = "32px";
find_room____.style.lineHeight = "40px";
find_room____.style.overflow = "hidden";
find_room____.style.color = "#D4C7C7";

page_post_login_page_ek1.appendChild(find_room____);

var rooms = document.createElement("div");
rooms.innerHTML = "Rooms";
rooms.style.fontWeight = "bold";
rooms.style.textAlign = "center";
rooms.id = "rooms";
rooms.style.left = "82px";
rooms.style.top = "221px";
rooms.style.width = "125px";
rooms.style.height = "62px";
rooms.style.fontFamily = "Istok Web";
rooms.style.fontSize = "32px";
rooms.style.lineHeight = "40px";
rooms.style.overflow = "hidden";
rooms.style.color = "#8D7E6C";

page_post_login_page_ek1.appendChild(rooms);

var profile_photo = document.createElement("div");
profile_photo.id = "profile_photo";
profile_photo.style.left = "1550px";
profile_photo.style.top = "66px";
profile_photo.style.width = "80px";
profile_photo.style.height = "80px";
profile_photo.style.borderRadius = "40px / 40px";
profile_photo.style.background = 'rgba(255,255,255,1)';

page_post_login_page_ek1.appendChild(profile_photo);

var website_name_ = document.createElement("div");
website_name_.innerHTML = "i.VOTE";
website_name_.style.textAlign = "center";
website_name_.id = "website_name_";
website_name_.style.left = "91px";
website_name_.style.top = "86px";
website_name_.style.width = "242px";
website_name_.style.height = "82px";
website_name_.style.fontFamily = "Coustard";
website_name_.style.fontSize = "60px";
website_name_.style.lineHeight = "40px";
website_name_.style.overflow = "hidden";
website_name_.style.color = "#000000";

page_post_login_page_ek1.appendChild(website_name_);

var welcome__team_f_d_a____ = document.createElement("div");
welcome__team_f_d_a____.innerHTML = "Welcome \'Team F.D.A\'...";
welcome__team_f_d_a____.style.textAlign = "left";
welcome__team_f_d_a____.id = "welcome__team_f_d_a____";
welcome__team_f_d_a____.style.left = "437px";
welcome__team_f_d_a____.style.top = "274px";
welcome__team_f_d_a____.style.width = "762px";
welcome__team_f_d_a____.style.height = "82px";
welcome__team_f_d_a____.style.fontFamily = "Coustard";
welcome__team_f_d_a____.style.fontSize = "60px";
welcome__team_f_d_a____.style.lineHeight = "40px";
welcome__team_f_d_a____.style.overflow = "hidden";
welcome__team_f_d_a____.style.color = "#FFFFFF";

page_post_login_page_ek1.appendChild(welcome__team_f_d_a____);

var create_room_button = document.createElement("div");
create_room_button.id = "create_room_button";
create_room_button.style.width = "482px";
create_room_button.style.height = "80px";
create_room_button.style.left = "425px";
create_room_button.style.top = "450px";
create_room_button.style.position = "absolute";
page_post_login_page_ek1.appendChild(create_room_button);

var rectangle_4 = document.createElement("div");
rectangle_4.id = "rectangle_4";
rectangle_4.style.left = "0px";
rectangle_4.style.top = "0px";
rectangle_4.style.width = "482px";
rectangle_4.style.height = "80px";
rectangle_4.style.borderRadius = "25px";
rectangle_4.style.background = 'rgba(0,137.27,180.62,1)';

create_room_button.appendChild(rectangle_4);

var create_room = document.createElement("div");
create_room.innerHTML = "Create Room";
create_room.style.textAlign = "center";
create_room.id = "create_room";
create_room.style.left = "90px";
create_room.style.top = "18px";
create_room.style.width = "314px";
create_room.style.height = "71.5px";
create_room.style.fontFamily = "Coustard";
create_room.style.fontSize = "45px";
create_room.style.lineHeight = "40px";
create_room.style.overflow = "hidden";
create_room.style.color = "#FFFFFF";

create_room_button.appendChild(create_room);

var join_room_button = document.createElement("div");
join_room_button.id = "join_room_button";
join_room_button.style.width = "372px";
join_room_button.style.height = "80px";
join_room_button.style.left = "437px";
join_room_button.style.top = "626px";
join_room_button.style.position = "absolute";
page_post_login_page_ek1.appendChild(join_room_button);

var rectangle_5 = document.createElement("div");
rectangle_5.id = "rectangle_5";
rectangle_5.style.left = "0px";
rectangle_5.style.top = "0px";
rectangle_5.style.width = "372px";
rectangle_5.style.height = "80px";
rectangle_5.style.borderRadius = "25px";
rectangle_5.style.background = 'rgba(0,137,181,1)';

join_room_button.appendChild(rectangle_5);

var join_room = document.createElement("div");
join_room.innerHTML = "Join Room";
join_room.style.textAlign = "center";
join_room.id = "join_room";
join_room.style.left = "66px";
join_room.style.top = "20px";
join_room.style.width = "262px";
join_room.style.height = "71.5px";
join_room.style.fontFamily = "Coustard";
join_room.style.fontSize = "45px";
join_room.style.lineHeight = "40px";
join_room.style.overflow = "hidden";
join_room.style.color = "#FFFFFF";

join_room_button.appendChild(join_room);

var rectangle_6 = document.createElement("div");
rectangle_6.id = "rectangle_6";
rectangle_6.style.left = "437px";
rectangle_6.style.top = "802px";
rectangle_6.style.width = "482px";
rectangle_6.style.height = "80px";
rectangle_6.style.borderRadius = "25px";
rectangle_6.style.background = 'rgba(0,137,181,1)';

page_post_login_page_ek1.appendChild(rectangle_6);
